# NAME

Planetgo logger

## DESCRIPTION

A separate module for using as logger in other planetgo resources.
